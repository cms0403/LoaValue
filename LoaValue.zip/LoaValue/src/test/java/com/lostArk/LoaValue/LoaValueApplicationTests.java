package com.lostArk.LoaValue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoaValueApplicationTests {

	@Test
	void contextLoads() {
	}

}
